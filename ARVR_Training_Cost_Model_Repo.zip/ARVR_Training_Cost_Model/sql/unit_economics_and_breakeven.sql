-- =============================================================================
-- REPOSITORY: ARVR_Training_Cost_Model
-- FILE: /sql/unit_economics_and_breakeven.sql
-- DESCRIPTION: Operational CapEx/OpEx cash model & unit-economics queries for
--              non-technical AR/VR warehouse & supply chain student training.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 1. COHORT-LEVEL CAPEX AMORTIZATION & UNIT ECONOMICS BREAKDOWN
-- Calculates amortized hardware CapEx per cohort, recurring OpEx, cost per
-- trained student, and net savings against traditional physical training.
-- -----------------------------------------------------------------------------
WITH CohortCostCalc AS (
    SELECT
        Cohort_ID,
        Training_Module,
        Campus_Hub,
        Batch_Size_Students,
        Active_Headsets_Allocated,
        -- Amortized CapEx per cohort across hardware useful life
        ROUND(
            (Active_Headsets_Allocated * Headset_Unit_CapEx_USD) / NULLIF(Hardware_Useful_Life_Cohorts, 0),
            2
        ) AS Amortized_CapEx_Cohort_USD,
        -- Recurring OpEx: Software licensing + Facilitator labor + Lab maintenance
        ROUND(
            (Batch_Size_Students * Software_License_Per_Seat_USD) +
            (Facilitator_Hours * Facilitator_Hourly_Rate_USD) +
            Lab_Maintenance_Overhead_USD,
            2
        ) AS Total_OpEx_Cohort_USD,
        Downtime_Pct,
        Completion_Rate_Pct,
        Traditional_Cost_Benchmark_Per_Student_USD
    FROM arvr_cohort_cost_parameters
)
SELECT
    Cohort_ID,
    Training_Module,
    Campus_Hub,
    Batch_Size_Students,
    Active_Headsets_Allocated,
    Amortized_CapEx_Cohort_USD,
    Total_OpEx_Cohort_USD,
    ROUND(Amortized_CapEx_Cohort_USD + Total_OpEx_Cohort_USD, 2) AS Total_Cohort_Cost_USD,
    ROUND((Amortized_CapEx_Cohort_USD + Total_OpEx_Cohort_USD) / Batch_Size_Students, 2) AS ARVR_Cost_Per_Student_USD,
    Traditional_Cost_Benchmark_Per_Student_USD,
    ROUND(
        Traditional_Cost_Benchmark_Per_Student_USD -
        ((Amortized_CapEx_Cohort_USD + Total_OpEx_Cohort_USD) / Batch_Size_Students),
        2
    ) AS Net_Savings_Per_Student_USD,
    ROUND(
        (1.0 - ((Amortized_CapEx_Cohort_USD + Total_OpEx_Cohort_USD) / Batch_Size_Students)
        / Traditional_Cost_Benchmark_Per_Student_USD) * 100.0,
        2
    ) AS Cost_Reduction_Pct
FROM CohortCostCalc
ORDER BY ARVR_Cost_Per_Student_USD ASC;


-- -----------------------------------------------------------------------------
-- 2. STUDENT-TO-HEADSET RATIO & LAB THROUGHPUT EFFICIENCY
-- Identifies optimal hardware allocation ratios that minimize unit costs
-- without triggering excessive headset downtime or lowering completion rates.
-- -----------------------------------------------------------------------------
SELECT
    ROUND(CAST(Batch_Size_Students AS FLOAT) / Active_Headsets_Allocated, 1) AS Student_To_Headset_Ratio,
    COUNT(Cohort_ID) AS Total_Cohorts,
    SUM(Batch_Size_Students) AS Total_Students_Trained,
    ROUND(AVG(Downtime_Pct), 2) AS Avg_Downtime_Pct,
    ROUND(AVG(Completion_Rate_Pct), 2) AS Avg_Completion_Rate_Pct,
    ROUND(
        AVG(
            (
                ((Active_Headsets_Allocated * Headset_Unit_CapEx_USD) / Hardware_Useful_Life_Cohorts) +
                (Batch_Size_Students * Software_License_Per_Seat_USD) +
                (Facilitator_Hours * Facilitator_Hourly_Rate_USD) +
                Lab_Maintenance_Overhead_USD
            ) / Batch_Size_Students
        ),
        2
    ) AS Avg_Cost_Per_Student_USD
FROM arvr_cohort_cost_parameters
GROUP BY ROUND(CAST(Batch_Size_Students AS FLOAT) / Active_Headsets_Allocated, 1)
ORDER BY Avg_Cost_Per_Student_USD ASC;


-- -----------------------------------------------------------------------------
-- 3. MODULE-LEVEL BREAK-EVEN BATCH SIZE ANALYSIS
-- Computes fixed cohort costs vs. variable per-student costs to determine
-- the minimum student batch size needed to beat traditional training benchmarks.
-- -----------------------------------------------------------------------------
WITH ModuleFixedVariable AS (
    SELECT
        Training_Module,
        AVG(
            ((Active_Headsets_Allocated * Headset_Unit_CapEx_USD) / Hardware_Useful_Life_Cohorts) +
            (Facilitator_Hours * Facilitator_Hourly_Rate_USD) +
            Lab_Maintenance_Overhead_USD
        ) AS Avg_Fixed_Cohort_Cost_USD,
        AVG(Software_License_Per_Seat_USD) AS Avg_Variable_Cost_Per_Student_USD,
        AVG(Traditional_Cost_Benchmark_Per_Student_USD) AS Benchmark_Per_Student_USD
    FROM arvr_cohort_cost_parameters
    GROUP BY Training_Module
)
SELECT
    Training_Module,
    ROUND(Avg_Fixed_Cohort_Cost_USD, 2) AS Avg_Fixed_Cohort_Cost_USD,
    ROUND(Avg_Variable_Cost_Per_Student_USD, 2) AS Variable_Cost_Per_Student_USD,
    ROUND(Benchmark_Per_Student_USD, 2) AS Benchmark_Per_Student_USD,
    -- Break-even students = Fixed Cost / (Benchmark Cost - Variable Cost per student)
    CEILING(
        Avg_Fixed_Cohort_Cost_USD /
        NULLIF(Benchmark_Per_Student_USD - Avg_Variable_Cost_Per_Student_USD, 0)
    ) AS Breakeven_Students_Per_Cohort
FROM ModuleFixedVariable
ORDER BY Breakeven_Students_Per_Cohort ASC;
