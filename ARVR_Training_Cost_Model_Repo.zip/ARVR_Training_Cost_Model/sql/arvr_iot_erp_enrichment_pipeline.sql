-- =============================================================================
-- REPOSITORY: ARVR_Training_Cost_Model
-- FILE: /sql/arvr_iot_erp_enrichment_pipeline.sql
-- BLUEPRINT ALIGNMENT:
--   - Block 4: Messy Raw Data Cleaning & Quality Validation
--   - Block 5: Multi-Source Enrichment (IoT Headset Telemetry + ERP Ledger)
--   - Block 6: Decision-Ready Unit Economics & Break-Even Outputs
-- =============================================================================

-- -----------------------------------------------------------------------------
-- STEP 1: DATA QUALITY & HYGIENE LAYER (CLEANING MESSY TELEMETRY LOGS)
-- Fixes duplicate webhook rows, standardizes campus names, and caps corrupted
-- sensor downtime readings before financial aggregation.
-- -----------------------------------------------------------------------------
WITH DeduplicatedTelemetry AS (
    SELECT
        Cohort_ID,
        TRIM(Training_Module) AS Training_Module,
        CASE
            WHEN UPPER(TRIM(Campus_Hub)) IN ('HUB A', 'CAMPUS A', 'CAMPUS HUB A') THEN 'Campus Hub A'
            WHEN UPPER(TRIM(Campus_Hub)) IN ('HUB B', 'CAMPUS B', 'CAMPUS HUB B') THEN 'Campus Hub B'
            WHEN UPPER(TRIM(Campus_Hub)) IN ('HUB C', 'CAMPUS C', 'CAMPUS HUB C') THEN 'Campus Hub C'
            ELSE 'Regional Center D'
        END AS Standardized_Campus_Hub,
        Batch_Size_Students,
        Active_Headsets_Allocated,
        Headset_Unit_CapEx_USD,
        COALESCE(NULLIF(Hardware_Useful_Life_Cohorts, 0), 20) AS Hardware_Useful_Life_Cohorts,
        Software_License_Per_Seat_USD,
        Facilitator_Hours,
        Facilitator_Hourly_Rate_USD,
        Lab_Maintenance_Overhead_USD,
        -- Cap corrupted negative or >50% sensor spikes to validated median (5.5%)
        CASE
            WHEN Downtime_Pct < 0 OR Downtime_Pct > 50 OR Downtime_Pct IS NULL THEN 5.50
            ELSE Downtime_Pct
        END AS Validated_Downtime_Pct,
        Completion_Rate_Pct,
        Traditional_Cost_Benchmark_Per_Student_USD,
        ROW_NUMBER() OVER (PARTITION BY Cohort_ID ORDER BY Training_Hours_Per_Student DESC) AS rn
    FROM arvr_cohort_cost_parameters
    WHERE Batch_Size_Students > 0
      AND Active_Headsets_Allocated > 0
),

-- -----------------------------------------------------------------------------
-- STEP 2: SECONDARY SOURCE ENRICHMENT (ERP FACILITY & ENERGY SURCHARGE INDEX)
-- Simulates joining regional ERP facility overhead & power surge multipliers
-- to measure true landed cohort cost by location.
-- -----------------------------------------------------------------------------
ErpFacilityEnrichment AS (
    SELECT 'Campus Hub A' AS Campus_Hub, 1.00 AS Facility_Power_Multiplier, 45.00 AS IT_Support_Flat_Fee_USD UNION ALL
    SELECT 'Campus Hub B', 1.05, 50.00 UNION ALL
    SELECT 'Campus Hub C', 1.12, 65.00 UNION ALL
    SELECT 'Regional Center D', 1.20, 85.00
),

EnrichedCohortModel AS (
    SELECT
        t.Cohort_ID,
        t.Training_Module,
        t.Standardized_Campus_Hub AS Campus_Hub,
        t.Batch_Size_Students,
        t.Active_Headsets_Allocated,
        ROUND(CAST(t.Batch_Size_Students AS FLOAT) / t.Active_Headsets_Allocated, 2) AS Student_To_Headset_Ratio,
        t.Validated_Downtime_Pct,
        t.Completion_Rate_Pct,
        -- Amortized Hardware CapEx per Cohort
        ROUND(
            (t.Active_Headsets_Allocated * t.Headset_Unit_CapEx_USD) / t.Hardware_Useful_Life_Cohorts,
            2
        ) AS Amortized_CapEx_USD,
        -- Enriched OpEx = Licensing + Facilitator Labor + (Lab Maintenance * ERP Power Multiplier) + IT Support Fee
        ROUND(
            (t.Batch_Size_Students * t.Software_License_Per_Seat_USD) +
            (t.Facilitator_Hours * t.Facilitator_Hourly_Rate_USD) +
            (t.Lab_Maintenance_Overhead_USD * e.Facility_Power_Multiplier) +
            e.IT_Support_Flat_Fee_USD,
            2
        ) AS Enriched_OpEx_USD,
        t.Traditional_Cost_Benchmark_Per_Student_USD
    FROM DeduplicatedTelemetry t
    LEFT JOIN ErpFacilityEnrichment e
        ON t.Standardized_Campus_Hub = e.Campus_Hub
    WHERE t.rn = 1
)

-- -----------------------------------------------------------------------------
-- STEP 3: EXECUTIVE DECISION OUTPUT (RATIO SWEET SPOT & UNIT SAVINGS)
-- -----------------------------------------------------------------------------
SELECT
    Campus_Hub,
    COUNT(Cohort_ID) AS Cohorts_Run,
    SUM(Batch_Size_Students) AS Total_Students,
    ROUND(AVG(Student_To_Headset_Ratio), 2) AS Avg_Student_Headset_Ratio,
    ROUND(AVG(Validated_Downtime_Pct), 2) AS Avg_Downtime_Pct,
    ROUND(AVG(Completion_Rate_Pct), 2) AS Avg_Completion_Pct,
    ROUND(SUM(Amortized_CapEx_USD + Enriched_OpEx_USD) / SUM(Batch_Size_Students), 2) AS Landed_Cost_Per_Student_USD,
    ROUND(
        AVG(Traditional_Cost_Benchmark_Per_Student_USD) -
        (SUM(Amortized_CapEx_USD + Enriched_OpEx_USD) / SUM(Batch_Size_Students)),
        2
    ) AS Net_Savings_Per_Student_USD
FROM EnrichedCohortModel
GROUP BY Campus_Hub
ORDER BY Landed_Cost_Per_Student_USD ASC;
