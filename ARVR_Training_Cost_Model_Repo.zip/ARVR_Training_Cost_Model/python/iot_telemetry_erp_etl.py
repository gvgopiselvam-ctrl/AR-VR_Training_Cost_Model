"""
REPOSITORY: ARVR_Training_Cost_Model
FILE: /python/iot_telemetry_erp_etl.py
DESCRIPTION:
    Ingests headset IoT session logs, applies data-hygiene rules, merges ERP
    facility cost centers, and outputs cohort-level unit economics.
"""

import pandas as pd
import numpy as np

def run_arvr_cost_pipeline(telemetry_csv: str, erp_csv: str) -> pd.DataFrame:
    df_tel = pd.read_csv(telemetry_csv)
    df_erp = pd.read_csv(erp_csv)

    # 1. Data Hygiene: Deduplicate cohort logs & validate sensor downtime
    df_tel = df_tel.drop_duplicates(subset=["Cohort_ID"], keep="first").copy()
    df_tel["Downtime_Pct"] = np.where(
        (df_tel["Downtime_Pct"] < 0) | (df_tel["Downtime_Pct"] > 50),
        df_tel["Downtime_Pct"].median(),
        df_tel["Downtime_Pct"]
    )

    # 2. Enrich with ERP Facility Overhead Ledger
    df = pd.merge(df_tel, df_erp, on="Campus_Hub", how="left")

    # 3. Compute CapEx Amortization & Enriched OpEx
    df["Student_Headset_Ratio"] = (df["Batch_Size_Students"] / df["Active_Headsets_Allocated"]).round(2)
    df["Amortized_CapEx_USD"] = (
        (df["Active_Headsets_Allocated"] * df["Headset_Unit_CapEx_USD"]) / df["Hardware_Useful_Life_Cohorts"]
    ).round(2)
    df["Enriched_OpEx_USD"] = (
        (df["Batch_Size_Students"] * df["Software_License_Per_Seat_USD"]) +
        (df["Facilitator_Hours"] * df["Facilitator_Hourly_Rate_USD"]) +
        (df["Lab_Maintenance_Overhead_USD"] * df["Facility_Power_Multiplier"]) +
        df["IT_Support_Flat_Fee_USD"]
    ).round(2)

    df["Total_Cohort_Cost_USD"] = (df["Amortized_CapEx_USD"] + df["Enriched_OpEx_USD"]).round(2)
    df["Landed_Unit_Cost_USD"] = (df["Total_Cohort_Cost_USD"] / df["Batch_Size_Students"]).round(2)
    df["Net_Savings_Per_Student_USD"] = (
        df["Traditional_Cost_Benchmark_Per_Student_USD"] - df["Landed_Unit_Cost_USD"]
    ).round(2)

    return df

if __name__ == "__main__":
    result = run_arvr_cost_pipeline(
        "data/arvr_cohort_cost_parameters.csv",
        "data/erp_facility_overhead_ledger.csv"
    )
    print(result[["Cohort_ID", "Campus_Hub", "Student_Headset_Ratio", "Landed_Unit_Cost_USD", "Net_Savings_Per_Student_USD"]].head(10).to_string(index=False))
